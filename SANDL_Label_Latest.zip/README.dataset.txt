# Snake & Lizard with fork tongue > 2024-12-31 1:00am
https://universe.roboflow.com/alienlabel/snake-lizard-with-fork-tongue

Provided by a Roboflow user
License: CC BY 4.0

