# Snake & Lizard with fork tongue > 2024-12-28 12:28pm
https://universe.roboflow.com/alienlabel/snake-lizard-with-fork-tongue

Provided by a Roboflow user
License: CC BY 4.0

