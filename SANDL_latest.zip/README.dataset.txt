# Snake & Lizard with fork tongue > 2024-12-23 3:59pm
https://universe.roboflow.com/alienlabel/snake-lizard-with-fork-tongue

Provided by a Roboflow user
License: CC BY 4.0

